import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/LoginController")
public class LoginController extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String un = request.getParameter("userid");
        String pw = request.getParameter("password1");

// Connect to mysql(mariadb) and verify username password
        if(un.equals("cog@cognizant.com")&&pw.equals("Cognizant@com")) {
       	 response.sendRedirect("home.html");
       }else {
        try {
            Class.forName("com.mysql.jdbc.Driver");
// loads driver
            Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","Saurabh@15"); // gets a new connection

            PreparedStatement ps = c.prepareStatement("select userid,password1 from myfood where userid=? and password1=?");
            ps.setString(1, un);
            ps.setString(2, pw);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                response.sendRedirect("home.html");
                return;
            }
            
            HttpSession httpSession=request.getSession();
            httpSession.setAttribute("msg","Invalid userid or password");          
            response.sendRedirect("Login.jsp");
            return;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
}